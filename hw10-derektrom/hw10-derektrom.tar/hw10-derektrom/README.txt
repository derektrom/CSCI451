/****************************
 * Derek Trom               *
 * derek.trom@und.edu       *
 * CSCI 451 HW 10 README    *
 * 16 November 2020         *
 * **************************/
1) open terminal and type "make"
   this will compile the program
2) In order to start main driver 
   program type "./program0"

